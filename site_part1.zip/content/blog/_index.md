<section class="mt-0 flex flex-col max-w-full dark:prose-invert">
  <h1 class="mt-1 mb-2 text-4xl font-extrabold text-neutral-900 dark:text-neutral">Recent Posts</h1>
  <hr class="mt-0 mb-6 border-t border-secondary-500 w-full">
</section>
