---
title: "文档"
description: "如何使用 Blowfish。"

cascade:
  showDate: false
  showAuthor: false
  invertPagination: true
---

{{< lead >}}
了解如何使用简单而强大的 Blowfish。
{{< /lead >}}

本章节包含了你需要了解的有关 Blowfish 的所有信息。如果你是新用户，请查阅[安装]({{< ref "docs/installation" >}}) 指南，或者访问[示例]({{< ref "samples" >}}) 来了解 Blowfish 能做什么。


---
