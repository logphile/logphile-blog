---
                title: "insidemordecai.com"
                tags: [个人网站]
                externalUrl: "https://insidemordecai.com"
                weight: 101
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

