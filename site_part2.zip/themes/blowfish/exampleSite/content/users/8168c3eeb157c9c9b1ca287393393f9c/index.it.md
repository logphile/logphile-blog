---
                title: "alanctanner.com"
                tags: [Sito personale]
                externalUrl: "https://alanctanner.com/"
                weight: 281
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

