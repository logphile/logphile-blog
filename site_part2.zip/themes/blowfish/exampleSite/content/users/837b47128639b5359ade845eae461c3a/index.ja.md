---
                title: "mrtruongvu.com"
                tags: [パーソナルサイト, ブログ]
                externalUrl: "https://mrtruongvu.com"
                weight: 931
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

