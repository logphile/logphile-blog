---
                title: "innerknowing"
                tags: [个人网站, 建模器]
                externalUrl: "https://innerknowing.xyz/en/"
                weight: 641
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

