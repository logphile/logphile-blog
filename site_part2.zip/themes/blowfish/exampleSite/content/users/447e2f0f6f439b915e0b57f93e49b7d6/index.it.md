---
                title: "Laterre Dev"
                tags: [Sito personale, Blog tecnologico, Sviluppatore del software, Sito di portafoglio]
                externalUrl: "https://laterre.dev/"
                weight: 951
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

