---
                title: "asterisk.lol"
                tags: [Blog, Sito personale]
                externalUrl: "https://asterisk.lol"
                weight: 591
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

