---
                title: "Middle of Nowhere"
                tags: [Personal Site,Blog]
                externalUrl: "https://blog.wtcx.dev/"
                weight: 741
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---
