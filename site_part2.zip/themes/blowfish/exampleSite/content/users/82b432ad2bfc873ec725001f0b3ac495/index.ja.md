---
                title: "BoringTech.net"
                tags: [パーソナルサイト, ブログ]
                externalUrl: "https://boringtech.net/"
                weight: 541
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

