---
title: "示例"
description: "来看看通过 Blowfish 能做到什么"

cascade:
  showEdit: false
  showSummary: false
  hideFeatureImage: true
---

{{< lead >}}
Blowfish 让你的内容栩栩如生。 :heart_eyes:
{{< /lead >}}

本节包含一些示例页面，展示了Blowfish如何呈现不同类型的内容。你还可以参考[标签]({{< ref "tags" >}})页面的示例。


_**旁注：** 这个页面只是一个标准的Blowfish文章列表，并且已经配置了Hugo来生成一个 `samples` 内容类型并显示文章摘要。_

---
