---
title: "外部の記事"
date: 2019-01-24
externalUrl: "https://nunocoracao.com/projects/"
summary: "`externalUrl` 表示は任意の URL にリンクすることができます。"
showReadingTime: true
_build:
  render: "false"
  list: "local"
type: 'sample'
---

このページは、 `externalUrl` 表示パラメータを利用して、この Hugo ウェブサイト外の記事とリンクしています。

Medium の投稿へのリンクや、サードパーティのウェブサイトでホストしている研究論文へのリンクなどに最適です。
